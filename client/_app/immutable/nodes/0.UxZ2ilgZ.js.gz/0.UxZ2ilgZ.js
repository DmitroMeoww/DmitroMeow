import{f,b as d}from"../chunks/BCyM_82f.js";import{ac as m,a7 as l,ab as s}from"../chunks/DcWvUvY3.js";import{h,s as g}from"../chunks/Cv6CAjhE.js";import{s as k,a as b}from"../chunks/aVNq5FiC.js";const u=m(`
:root {
  color-scheme: light dark;
}
@layer tokens {
  :root {
    --m3c-surface: light-dark(#f8f9fe, #0c0e11);
    --m3c-surface-container-lowest: light-dark(#fff, #000);
    --m3c-surface-container-low: light-dark(#f1f4f9, #101418);
    --m3c-surface-container: light-dark(#eaeef5, #151a1f);
    --m3c-surface-container-high: light-dark(#e4e8f0, #1b2025);
    --m3c-surface-container-highest: light-dark(#dde3eb, #20262d);
    --m3c-on-surface: light-dark(#2d333a, #e0e6ee);
    --m3c-on-surface-variant: light-dark(#5a6067, #a6acb4);
    --m3c-outline: light-dark(#757b83, #70767d);
    --m3c-outline-variant: light-dark(#adb2ba, #42484f);
    --m3c-inverse-surface: light-dark(#0c0e11, #f8f9fe);
    --m3c-inverse-on-surface: light-dark(#9b9da1, #535559);
    --m3c-primary: light-dark(#386386, #abcae9);
    --m3c-on-primary: light-dark(#f6f9ff, #23435d);
    --m3c-primary-container: light-dark(#acd6ff, #375570);
    --m3c-on-primary-container: light-dark(#1d4b6d, #cee6ff);
    --m3c-inverse-primary: light-dark(#acd6ff, #43627d);
    --m3c-secondary: light-dark(#526170, #b9c8da);
    --m3c-on-secondary: light-dark(#f6f9ff, #334250);
    --m3c-secondary-container: light-dark(#d4e4f6, #2e3d4b);
    --m3c-on-secondary-container: light-dark(#445362, #b1c1d2);
    --m3c-tertiary: light-dark(#5c5b85, #d9d6ff);
    --m3c-on-tertiary: light-dark(#fbf7ff, #494971);
    --m3c-tertiary-container: #cac7f8;
    --m3c-on-tertiary-container: #404068;
    --m3c-error: light-dark(#a83836, #fa746f);
    --m3c-on-error: light-dark(#fff7f6, #490006);
    --m3c-error-container: light-dark(#fa746f, #871f21);
    --m3c-on-error-container: light-dark(#6e0a12, #ff9993);
    --m3c-shadow: #000;
    --m3c-scrim: #000;
    --m3c-on-on-primary: light-dark(#386286, #aacae9);
    --m3c-primary-container-subtle: light-dark(#bddeff, #0b2e47);
    --m3c-on-primary-container-subtle: light-dark(#235072, #8faecd);
    --m3c-secondary-container-subtle: light-dark(#ccdcee, #1f2e3b);
    --m3c-on-secondary-container-subtle: light-dark(#3f4e5d, #9dadbe);
    --m3c-tertiary-container-subtle: light-dark(#d9d6ff, #29284e);
    --m3c-on-tertiary-container-subtle: light-dark(#494971, #a8a7d5);
    --m3c-error-container-subtle: light-dark(#ffcfcb, #60000a);
    --m3c-on-error-container-subtle: light-dark(#8f2526, #ff8983);
  }
}
`);var y=f("<!> <!>",1);function w(e,t){const c=()=>b(u,"$blue_theme",i),[i,n]=k();var r=y(),a=l(r);h(a,()=>`<style>${c()}</style>`);var o=s(a,2);g(o,()=>t.children),d(e,r),n()}export{w as component};
