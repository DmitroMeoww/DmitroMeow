import{l as o,a as r}from"../chunks/E6V6HNOa.js";export{o as load_css,r as start};
